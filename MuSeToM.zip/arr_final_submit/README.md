# MuSeToM Dataset Submission

This folder contains the reviewer-facing MuSeToM data instances used for the paper:

> MuSeToM: A Multi-Sensory Benchmark for Evaluating Theory of Mind Reasoning in Large Language Models

MuSeToM evaluates whether a model can decide when perceptual evidence is sufficient for a protagonist to revise an initial belief, and whether the model can identify the resulting updated belief.

## Contents

- `data/musetom_bigtom.jsonl`: validated MuSeToM instances derived from BigToM.
- `data/musetom_opentom.jsonl`: validated MuSeToM instances derived from OpenToM.
- `prompt_templates/`: active zero-shot prompt templates for Tasks 1-4.
- `metadata/schema.md`: field definitions for the JSONL files.
- `metadata/statistics.json`: paper-claimed and computed statistics for the released instance files.
- `scripts/validate_statistics.py`: reproduces the instance, category, and modality counts.

Model outputs, metric spreadsheets, temporary prompt previews, and working experiment folders are intentionally not included in this final data submission bundle.

## Dataset Statistics

These are the statistics claimed in `arr_rush/latex/acl_latex.tex` under `tab:dataset_statistics`.

| Dataset | Source stories | Total instances | Positive | Hard negative | Easy negative |
|---|---:|---:|---:|---:|---:|
| BigToM | 100 | 1,169 | 501 | 246 | 422 |
| OpenToM | 120 | 1,246 | 511 | 231 | 504 |
| Total | 220 | 2,415 | 1,012 | 477 | 926 |

| Dataset | Visual | Auditory | Olfactory | Gustatory | Tactile | Proprioception |
|---|---:|---:|---:|---:|---:|---:|
| BigToM | 349 | 259 | 135 | 73 | 247 | 106 |
| OpenToM | 401 | 327 | 174 | 80 | 198 | 66 |
| Total | 750 | 586 | 309 | 153 | 445 | 172 |

Run the validator from the repository root:

```bash
python3 arr_final_submit/scripts/validate_statistics.py
```

Expected result:

```text
All paper instance/category/modality statistics match.
```

The validator also prints unique story-text and ID-prefix counts for transparency. The paper's `Source stories` column is the source-sampling count reported in the manuscript; the JSONL files do not contain a separate `source_story_id` field.

## Task Mapping

- Task 1: clean belief-change detection.
- Task 2: clean updated-belief identification.
- Task 3: noisy belief-change detection.
- Task 4: noisy updated-belief identification.

The two JSONL files contain the validated cue instances counted in the paper. For noisy Tasks 3 and 4, the evaluation setting pairs positive or hard-negative cue instances with distractor cues from easy-negative instances, as described in the paper.

## Source Terms

MuSeToM is derived from BigToM and OpenToM. Please follow the usage terms of the original source datasets and cite the original BigToM and OpenToM papers when using this benchmark.
