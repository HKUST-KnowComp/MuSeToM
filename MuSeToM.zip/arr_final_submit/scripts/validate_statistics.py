#!/usr/bin/env python3
"""Validate MuSeToM release statistics against the paper table."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DATA_FILES = {
    "bigtom": ROOT / "data" / "musetom_bigtom.jsonl",
    "opentom": ROOT / "data" / "musetom_opentom.jsonl",
}

EXPECTED: dict[str, dict[str, Any]] = {
    "bigtom": {
        "total": 1169,
        "groundtruth_classification": {
            "positive": 501,
            "hard_negative": 246,
            "easy_negative": 422,
        },
        "sense": {
            "visual": 349,
            "auditory": 259,
            "olfactory": 135,
            "gustatory": 73,
            "tactile": 247,
            "proprio": 106,
        },
    },
    "opentom": {
        "total": 1246,
        "groundtruth_classification": {
            "positive": 511,
            "hard_negative": 231,
            "easy_negative": 504,
        },
        "sense": {
            "visual": 401,
            "auditory": 327,
            "olfactory": 174,
            "gustatory": 80,
            "tactile": 198,
            "proprio": 66,
        },
    },
}


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON at {path}:{line_number}: {exc}") from exc
    return rows


def count_field(rows: list[dict[str, Any]], field: str) -> dict[str, int]:
    return dict(Counter(str(row.get(field)) for row in rows))


def validate_dataset(name: str, rows: list[dict[str, Any]]) -> list[str]:
    failures: list[str] = []
    expected = EXPECTED[name]

    actual_total = len(rows)
    if actual_total != expected["total"]:
        failures.append(f"{name}: total rows {actual_total} != {expected['total']}")

    for field in ("groundtruth_classification", "sense"):
        actual = count_field(rows, field)
        if actual != expected[field]:
            failures.append(f"{name}: {field} counts {actual} != {expected[field]}")

    return failures


def main() -> None:
    all_failures: list[str] = []
    totals = Counter()
    class_totals = Counter()
    sense_totals = Counter()

    for name, path in DATA_FILES.items():
        rows = load_jsonl(path)
        all_failures.extend(validate_dataset(name, rows))
        totals["instances"] += len(rows)
        class_totals.update(row["groundtruth_classification"] for row in rows)
        sense_totals.update(row["sense"] for row in rows)

        unique_story_texts = len({row.get("story", "") for row in rows})
        unique_id_prefixes = len({str(row.get("ID", "")).split("-")[0] for row in rows})
        print(
            f"{name}: rows={len(rows)}, unique_story_texts={unique_story_texts}, "
            f"unique_id_prefixes={unique_id_prefixes}"
        )

    expected_total = EXPECTED["bigtom"]["total"] + EXPECTED["opentom"]["total"]
    expected_class_totals = {
        "positive": 1012,
        "hard_negative": 477,
        "easy_negative": 926,
    }
    expected_sense_totals = {
        "visual": 750,
        "auditory": 586,
        "olfactory": 309,
        "gustatory": 153,
        "tactile": 445,
        "proprio": 172,
    }

    if totals["instances"] != expected_total:
        all_failures.append(f"combined: total rows {totals['instances']} != {expected_total}")
    if dict(class_totals) != expected_class_totals:
        all_failures.append(
            f"combined: groundtruth_classification counts {dict(class_totals)} "
            f"!= {expected_class_totals}"
        )
    if dict(sense_totals) != expected_sense_totals:
        all_failures.append(f"combined: sense counts {dict(sense_totals)} != {expected_sense_totals}")

    if all_failures:
        print("Statistics validation failed:")
        for failure in all_failures:
            print(f"- {failure}")
        raise SystemExit(1)

    print("All paper instance/category/modality statistics match.")


if __name__ == "__main__":
    main()
