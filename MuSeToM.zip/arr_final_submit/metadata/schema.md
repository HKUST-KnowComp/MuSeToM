# MuSeToM JSONL Schema

Each line in `data/musetom_bigtom.jsonl` and `data/musetom_opentom.jsonl` is one validated perceptual-cue instance.

## Common Fields

- `ID`: instance identifier in the source-specific generation pipeline.
- `category`: coarse generation bucket. Most positive and hard-negative rows use `pos/hard_neg`; easy negatives use `easy_neg`.
- `sense`: sensory modality. Values are `visual`, `auditory`, `olfactory`, `gustatory`, `tactile`, and `proprio`.
- `story`: story context shown to the model.
- `protag_name`: protagonist whose belief is queried.
- `percept_cue`: perceptual evidence observed by the protagonist.
- `initial_belief`: protagonist's belief before the queried perceptual evidence.
- `default_question`: natural-language updated-belief question.
- `answer_options`: four answer options for the updated-belief identification tasks.
- `groundtruth_classification`: validated cue type. Values are `positive`, `hard_negative`, and `easy_negative`.
- `belief_change_label`: binary gold label for belief-change detection. `1` means the belief should change; `0` means it should not.
- `belief_change_label_raw`: annotator-level aggregate before final binarization.
- `new_belief_label`: gold option label for updated-belief identification.
- `new_belief_label_raw`: annotator-level updated-belief option labels.

## BigToM-Only Field

- `event`: belief-relevant event from the BigToM-derived scenario.

## Label Semantics

- `positive`: the perceptual cue provides sufficient evidence for belief revision.
- `hard_negative`: the perceptual cue is related or salient but insufficient to justify belief revision.
- `easy_negative`: the perceptual cue is irrelevant to the queried belief revision.

Use `groundtruth_classification` for the paper's Positive/Hard negative/Easy negative statistics. Use `sense` for the modality statistics.
